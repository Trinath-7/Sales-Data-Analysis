To run the `full_analysis_report.html` file from Visual Studio Code, follow these steps:

1. **Open Visual Studio Code**: Launch the application.

2. **Open the File**: Use the menu to navigate to File > Open File... and select the `full_analysis_report.html` file located at `c:\Users\krish\OneDrive\Desktop\Retail_Sales_Project\`.

3. **Install Live Server Extension** (if not already installed):
   - Go to the Extensions view by clicking on the Extensions icon in the Activity Bar on the side of the window or by pressing `Ctrl+Shift+X`.
   - Search for "Live Server" and install it.

4. **Run the HTML File**:
   - Once the file is open, right-click anywhere in the editor and select "Open with Live Server".
   - This will launch your default web browser and display the HTML file.

5. **View Changes**: Any changes you make to the HTML file will automatically refresh in the browser.

By following these steps, you can easily run and view your HTML file in a web browser directly from Visual Studio Code.